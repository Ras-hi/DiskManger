import os
import psutil
import hashlib
import shutil

def get_file_type(filename):
    _, extension = os.path.splitext(filename)
    return extension.lower()

def calculate_directory_size(directory):
    total_size = 0
    for dirpath, _, filenames in os.walk(directory):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            total_size += os.path.getsize(filepath)
    return total_size

def get_space_utilization(directory_path):
    space_utilization = {
        "Images": 0,
        "Videos": 0,
        ".py Files": 0,
        "Other Files": {}
    }

    for dirpath, _, filenames in os.walk(directory_path):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            file_size = os.path.getsize(filepath)
            file_type = get_file_type(filename)

            # Categorize the file based on its type
            if file_type in (".jpg", ".png", ".gif", ".bmp"):
                space_utilization["Images"] += file_size
            elif file_type in (".mp4", ".avi", ".mkv", ".mov"):
                space_utilization["Videos"] += file_size
            elif file_type == ".py":
                space_utilization[".py Files"] += file_size
            else:
                space_utilization["Other Files"].setdefault(file_type, 0)
                space_utilization["Other Files"][file_type] += file_size

    return space_utilization

def get_file_hash(filepath):
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def get_large_files(path, min_size):
    large_files = []
    for dirpath, _, filenames in os.walk(path):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            file_size = os.path.getsize(filepath)
            if file_size >= min_size:
                large_files.append((filepath, file_size))
    return large_files

def scan_specific_file_type(path, file_type):
    matched_files = []
    for dirpath, _, filenames in os.walk(path):
        for filename in filenames:
            if filename.endswith(file_type):
                filepath = os.path.join(dirpath, filename)
                matched_files.append(filepath)
    return matched_files

def delete_files_by_type(path, file_type):
    matched_files = scan_specific_file_type(path, file_type)
    temp_folder = os.path.join(os.getcwd(), "deleted_files_temp")
    log_file = os.path.join(os.getcwd(), "deleted_files_log.txt")

    if not os.path.exists(temp_folder):
        os.makedirs(temp_folder)

    with open(log_file, "a") as f:
        for file in matched_files:
            try:
                # Move the file to the temporary folder
                new_location = os.path.join(temp_folder, os.path.basename(file))
                shutil.move(file, new_location)
                print(f"Deleted: {file}")
                # Write to log file
                f.write(f"{file}\n")
            except Exception as e:
                print(f"Error deleting {file}: {e}")

def retrieve_deleted_files():
    temp_folder = os.path.join(os.getcwd(), "deleted_files_temp")
    log_file = os.path.join(os.getcwd(), "deleted_files_log.txt")

    if not os.path.exists(temp_folder):
        print("No files have been deleted.")
        return

    with open(log_file, "r") as f:
        deleted_files = f.read().splitlines()

    for deleted_file in deleted_files:
        temp_file = os.path.join(temp_folder, os.path.basename(deleted_file))
        try:
            # Move the file back to its original location
            shutil.move(temp_file, deleted_file)
            print(f"Retrieved: {deleted_file}")
        except Exception as e:
            print(f"Error retrieving {deleted_file}: {e}")

    # Remove the temporary folder and log file
    shutil.rmtree(temp_folder)
    os.remove(log_file)

def main():
    while True:
        # Get disk usage
        drive = input("\nEnter the drive path (e.g., C:\\, D:\\, etc.) or 'exit' to quit: ")

        if drive.lower() == 'exit':
            print("Exiting the program.")
            break

        if not os.path.exists(drive) or not os.path.isdir(drive):
            print("Invalid drive path.")
            continue

        print("\nChoose an option:")
        print("1. Get Disk Space Usage")
        print("2. Find Duplicate Files")
        print("3. Find Large Files")
        print("4. Scan Specific File Type")
        print("5. Delete Files by Type")
        print("6. Retrieve Deleted Files")
        print("7. Exit")
        choice = input("Enter the option number: ")

        if choice == "1":
            # Get disk usage
            total_disk_space = psutil.disk_usage(drive).total
            used_disk_space = psutil.disk_usage(drive).used
            free_disk_space = psutil.disk_usage(drive).free

            # Display the information
            print(f"\nTotal Disk Space: {total_disk_space} bytes")
            print(f"Used Disk Space: {used_disk_space} bytes")
            print(f"Free Disk Space: {free_disk_space} bytes")

        elif choice == "2":
            # Find duplicate files
            file_hashes = {}
            duplicates = []

            for dirpath, _, filenames in os.walk(drive):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    file_hash = get_file_hash(filepath)
                    if file_hash in file_hashes:
                        duplicates.append((filepath, file_hashes[file_hash]))
                    else:
                        file_hashes[file_hash] = filepath

            # Display the duplicate files
            if duplicates:
                print("\nDuplicate Files:")
                for duplicate in duplicates:
                    print(f"Duplicate: {duplicate[0]} and {duplicate[1]}")
            else:
                print("\nNo duplicate files found.")

        elif choice == "3":
            # Find large files
            min_size = int(input("Enter the minimum size (in bytes) for large files: "))
            large_files = get_large_files(drive, min_size)

            # Display the large files
            if large_files:
                print("\nLarge Files:")
                for file_info in large_files:
                    print(f"Large File: {file_info[0]} - Size: {file_info[1]} bytes")
            else:
                print("\nNo large files found.")

        elif choice == "4":
            # Scan specific file type
            file_type = input("Enter the file type to scan (e.g., '.txt', '.jpg'): ")
            specific_files = scan_specific_file_type(drive, file_type)

            # Display the matched files
            if specific_files:
                print(f"\nMatched Files of Type '{file_type}':")
                for filepath in specific_files:
                    print(filepath)
            else:
                print(f"\nNo files of type '{file_type}' found.")

        elif choice == "5":
            # Delete files by type
            file_type = input("Enter the file type to delete (e.g., '.txt', '.jpg'): ")
            delete_files_by_type(drive, file_type)

        elif choice == "6":
            # Retrieve deleted files
            retrieve_deleted_files()

        elif choice == "7":
            print("Exiting the program.")
            break

        else:
            print("Invalid option. Ple*ase choose a valid option.")

if __name__ == "__main__":
    main()





REFERENCES:
1-  https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.systweak.com%2Fblogs%2Fduplicate-files-a-study-of-their-detection-and-management%2F%23%3A~%3Atext%3DIdentical%2520content%253A%2520Duplicate%2520files%2520have%2Csame%2520file%2520format%252C%2520such%2520as%2520.&data=05%7C01%7Cshubham.nigam%40tallysolutions.com%7C1f2559ac89944f0316eb08db88465916%7C66bcd9b727254893bb969ae424774af6%7C0%7C0%7C638253607942852221%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=25H1tP%2FPMllO8c2q5AK75OtvmdMUsNR8Q57pD%2FzX04U%3D&reserved=0

2-  https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.systweak.com%2Fblogs%2Fduplicate-files-a-study-of-their-detection-and-management%2F%23%3A~%3Atext%3DIdentical%2520content%253A%2520Duplicate%2520files%2520have%2Csame%2520file%2520format%252C%2520such%2520as%2520.&data=05%7C01%7Cshubham.nigam%40tallysolutions.com%7C1f2559ac89944f0316eb08db88465916%7C66bcd9b727254893bb969ae424774af6%7C0%7C0%7C638253607942852221%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=25H1tP%2FPMllO8c2q5AK75OtvmdMUsNR8Q57pD%2FzX04U%3D&reserved=0

3- https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fopensource.com%2Farticle%2F22%2F4%2Fsystems-programming&data=05%7C01%7Cshubham.nigam%40tallysolutions.com%7C1f2559ac89944f0316eb08db88465916%7C66bcd9b727254893bb969ae424774af6%7C0%7C0%7C638253607942852221%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=MfUGTdF22qoizarvx3Esy2W0cs3FwzlpMbPxVnGsss8%3D&reserved=0


4- https://www.bing.com/ck/a?!&&p=1c68fa80bfba4932JmltdHM9MTY4OTg5NzYwMCZpZ3VpZD0xMDRhMDhlZS04MGJkLTY0NWItMTRmZi0xODBiODE3MTY1OTMmaW5zaWQ9NTIxMg&ptn=3&hsh=3&fclid=104a08ee-80bd-645b-14ff-180b81716593&psq=CLI+app&u=a1aHR0cHM6Ly9naXRodWIuY29tL2FnYXJyaGFyci9hd2Vzb21lLWNsaS1hcHBz&ntb=1

5- https://www.bing.com/ck/a?!&&p=1ebb313f88c81d94JmltdHM9MTY4OTg5NzYwMCZpZ3VpZD0xMDRhMDhlZS04MGJkLTY0NWItMTRmZi0xODBiODE3MTY1OTMmaW5zaWQ9NTIwOQ&ptn=3&hsh=3&fclid=104a08ee-80bd-645b-14ff-180b81716593&psq=command-line+interface&u=a1aHR0cHM6Ly93d3cudzNzY2hvb2xzLmNvbS93aGF0aXMvd2hhdGlzX2NsaS5hc3A&ntb=1


6- https://www.bing.com/ck/a?!&&p=afb8496451d58168JmltdHM9MTY4OTg5NzYwMCZpZ3VpZD0xMDRhMDhlZS04MGJkLTY0NWItMTRmZi0xODBiODE3MTY1OTMmaW5zaWQ9NTUxMg&ptn=3&hsh=3&fclid=104a08ee-80bd-645b-14ff-180b81716593&psq=cli+python+librarires&u=a1aHR0cHM6Ly9tZWRpdW0uY29tL0BuYXRpZ2luZm8vNS1weXRob24tbGlicmFyaWVzLXRvLWJ1aWxkLWNvbW1hbmQtbGluZS10b29scy05NTE3MzRlOTJjMTYjOn46dGV4dD01JTIwUHl0aG9uJTIwTGlicmFyaWVzJTIwdG8lMjBCdWlsZCUyMENvbW1hbmQlMjBMaW5lJTIwVG9vbHMsdGFsayUyMGFib3V0JTIwaXMlMjBQeUZpZ2xldC4lMjAuLi4lMjA1JTIwVGFidWxhdGUlMjA&ntb=1
